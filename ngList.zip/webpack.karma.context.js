
let context = require.context('./app', true, /\.js/); // /\.test\.js/);
context.keys().forEach(context);
//console.log(context.keys());
