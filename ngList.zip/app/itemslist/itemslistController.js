export default class itemslistController {
	constructor() {
		this.controllerName = 'itemsList Controller';
	}
}
