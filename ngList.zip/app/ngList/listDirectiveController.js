
export default class listDirectiveController {
	
	constructor() {
		var self = this;
				
		self.items = [{       id: 1,       name: 'Apple',       active: true     }, {       id: 2,       name: 'Orange',       active: true     }, {       id: 3,       name: 'Banana',       active: false     }, {       id: 4,       name: 'Kiwi',       active: true     }, {       id: 5,       name: 'Avocado',       active: false     }];
		
		self.updateItems();
	}
	
	switchStatus(item) {
	  var self = this;
      item.active = !item.active;
      self.updateItems();
    }
	
	updateItems(filteredItems) {
	  var self = this;
      var collection = filteredItems || self.items;
      self.activeItems = collection.filter(function(item) {
        return item.active;
      });
      
      self.inactiveItems = collection.filter(function(item) {
        return !item.active;
      });
    }
	
}