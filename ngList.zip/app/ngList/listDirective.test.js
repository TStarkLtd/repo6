import listDirective from './listDirective.js';
import listDirectiveController from './listDirectiveController.js';

let directive;

describe('Directive: ngList', function() {

    beforeEach(function() {
        directive = new listDirective();
		
		jasmine.addMatchers({
			toBeInstanceOf: (util, customEqualityTesters) => {
				return {
					compare: (actual, expected) => {
						const pass = (actual instanceof expected);
						return {
							pass,
							message: `Expected ${actual} to ${pass ? 'not' : ''} be instance of ${expected}`,
						};
					}					
				};
			},

			toBeSameFunction: () => {
				return {
					compare: (actual, expected) => {
						const pass = (actual === expected); // ( actual.toString() == expected.toString() ); 
						return {
							pass,
							message: `Expected ${actual} to ${pass ? 'not' : ''} be same function of ${expected}`,
						};
					}					
				};
			},
			
			});
		
		
    });

    afterEach(function() {
       
    });

    it('should contain template after initialization', function () {
		
        expect(directive.template).toBeDefined();
		
    });
	
	it('should contain scope after initialization', function () {
		
        expect(directive.scope).toBeDefined();
		expect(directive.scope).toEqual( jasmine.any(Object) );
		
    });
	
	it('should contain restrict after initialization', function () {
		
        expect(directive.restrict).toBeDefined();
		expect(directive.restrict).toEqual('EA');
		
    });
	
	it('should contain controller after initialization', function () {
		
        expect(directive.controller).toBeDefined();
		expect(directive.controller).toEqual( jasmine.any(Function) );
		expect(directive.controller).toBeSameFunction(listDirectiveController);
		
    });
	
	it('should contain controllerAs after initialization', function () {
		
        expect(directive.controllerAs).toBeDefined();
		expect(directive.controllerAs).toEqual('ctrl');
		
    });
	
	it('should contain bindToController after initialization', function () {
		
        expect(directive.bindToController).toBeDefined();
		expect(directive.bindToController).toBeTruthy();
		
    });


});