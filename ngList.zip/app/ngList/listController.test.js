import listController from './listController.js';

let controller;

describe('Controller: ngList', function() {

    beforeEach(function() {
        controller = new listController();
    });

    afterEach(function() {
       
    });

    it('should contain controllerName after initialization', function () {
		
        expect(controller.controllerName).toBeDefined();
        expect(controller.controllerName).toEqual('ngList Controller');
		
    });


});