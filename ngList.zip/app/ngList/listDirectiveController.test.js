import listDirectiveController from './listDirectiveController.js';

let controller;

describe('Directive Controller: ngList', function() {

    beforeEach(function() {
        controller = new listDirectiveController();
    });

    afterEach(function() {
       
    });

    it('should contain items after initialization', function () {
        
		expect(controller.items).toBeDefined();
		expect(controller.items).toEqual( jasmine.any(Array) );
		expect(controller.items.length).toEqual(5);
		
    });
	
	it('should contain updateItems after initialization', function () {
        
		expect(controller.updateItems).toBeDefined();
		expect(controller.updateItems).toEqual( jasmine.any(Function) );
		
    });
	
	it('should contain switchStatus after initialization', function () {
        
		expect(controller.switchStatus).toBeDefined();
		expect(controller.switchStatus).toEqual( jasmine.any(Function) );
		
    });
	
	it('should switch item status', function () {
		var item = controller.items[0];
        var originalStatus = item.active;
		controller.switchStatus(item);
		var updatedStatus = item.active;
		expect( originalStatus == !updatedStatus ).toBeTruthy();
		
    });
	
	it('should update items after switchStatus', function () {
		var item = controller.items[0];
		
		expect(item.active).toBeTruthy();
		
		var activeItemsCountOrginal = controller.activeItems.length;
		var inactiveItemsCountOrginal = controller.inactiveItems.length;
		
		controller.switchStatus(item);
		
		var activeItemsCountUpdated = controller.activeItems.length;
		var inactiveItemsCountUpdated = controller.inactiveItems.length;
		
		expect(activeItemsCountOrginal - activeItemsCountUpdated).toEqual(1);
		
		expect(inactiveItemsCountOrginal - inactiveItemsCountUpdated).toEqual(-1);
		
    });


});