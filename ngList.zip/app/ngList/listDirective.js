import listDirectiveController from './listDirectiveController.js';

export default class listDirective {
    constructor() {
        this.template = '<div class="main"> <items-list data-title="Items On Sale" data-items="ctrl.activeItems" data-on-click="ctrl.switchStatus(item)"></items-list> \
 <items-list data-title="Items Sold Out" data-items="ctrl.inactiveItems" data-on-click="ctrl.switchStatus(item)"></items-list> </div>';
        this.scope = {};
		this.restrict = 'EA';
        this.controller = listDirectiveController;
        this.controllerAs = 'ctrl';
        this.bindToController = true;
    }

    // Directive compile function
    compile(tElement, tAttrs) {
				
    }
    
    // Directive link function
    link(scope, elem, attr, ctr) {
		
    }
}

