export default class listController {
	constructor() {
		this.controllerName = 'ngList Controller';
	}
}
