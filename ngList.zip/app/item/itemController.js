export default class itemController {
	constructor() {
		this.controllerName = 'item Controller';
	}
}
