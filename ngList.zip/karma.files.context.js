let context = require.context('./app', true, /\.js/);
context.keys().forEach(context);
console.log(context.keys());

//let context = require.context('./app', true, /^((?!test).)*$/);
//context.keys().forEach(context);
//console.log(context.keys());
