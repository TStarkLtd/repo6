var webpack = require('webpack');
const prod = process.argv.indexOf('-p') !== -1;

/*
 * Default webpack configuration for development
 */
var config = {
  devtool: 'inline-source-map', //devtool: 'source-map',
  entry: { 
		ngApp : __dirname + "/app/ngApp.js",
	},
  output: {
    path: __dirname + "/public",
    filename: "[name].bundle.js"
  },
  module: {
	preLoaders: [
          {
            test: /\.js?$/,
            include: /app/,
            exclude: [/node_modules/, /\.test\.js$/, /webpack\.karma\.context\.js/],
            loader: 'babel',
            query: {
              cacheDirectory: true,
            },
          },
		  {
			test: /\.html$/,
			loader: 'html',
			query: {
				minimize: true
			}
		  }
        ],
    loaders: [
		  {
            test: /\.js$/,
			include: /app/,
            exclude: [/node_modules/, /\.test\.js$/, /webpack\.karma\.context\.js/],
            loader: 'babel',
          },
		  {
			test: /\.html$/,
			loader: 'html',
			query: {
				minimize: true
			}
		  }
	]
  },
  devServer: {
    contentBase: "./public",
    colors: true,
    historyApiFallback: true,
    inline: true
  },
  plugins: [
    new webpack.optimize.OccurenceOrderPlugin(),
	new webpack.ProvidePlugin({
            $: 'jquery',
            jQuery: 'jquery'
        })
  ]
}


if (prod) { config.devtool = false;
  config.plugins.push( new webpack.DefinePlugin({
      'process.env': {
          'NODE_ENV': JSON.stringify('production')
      }
  }) );
  config.plugins.push( new webpack.optimize.UglifyJsPlugin({ minimize: true, comments: false, compressor:{warnings:false} }) );
};


/*
 * If bundling for production, optimize output
 */
 /*
if (process.env.NODE_ENV === 'production') {
  config.devtool = false;
  config.plugins = [
    new webpack.optimize.OccurenceOrderPlugin(),
    new webpack.DefinePlugin({
      'process.env': {'NODE_ENV': JSON.stringify('production')}
    }),
	new webpack.optimize.UglifyJsPlugin({ minimize: true, comments: false, compressor:{warnings:false} }),
  ];
};
 */
module.exports = config;
