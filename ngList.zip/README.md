
NG List App
=====================

Quickstart project template for List App in AngularJS1.

### Objective

This project is used to learn how to create AngularJS1 projects with Webpack and Babel. It aims to be a starting point for learning AngularJS1, while providing a solid foundation for new AngularJS1 projects.
