var webpack = require('webpack');
var path = require('path');
var webpackConfig = require('./webpack.config');

webpackConfig.entry = {};
webpackConfig.output = {};
webpackConfig.module.preLoaders = [
          {
            test: /\.test\.js$/,
			include: /app/,
            exclude: /node_modules/,
            loader: 'babel',
            query: {
              cacheDirectory: true,
            },
          },
          {
            test: /\.js?$/,
            include: /app/,
            exclude: [/node_modules/, /\.test\.js$/, /webpack\.karma\.context\.js/],
            loader: 'babel-istanbul',
            query: {
              cacheDirectory: true,
            },
          },
		  {
			test: /\.html$/,
			loader: 'html',
			query: {
				minimize: true
			}
		  }
		  ];


module.exports = function(config) {
    config.set({
        browsers:   ['Chrome'],
        frameworks: ['jasmine'],
        reporters:  ['progress', 'coverage', 'spec'],
		coverageReporter: {
			// output coverage reports
			//type : 'html',
			dir : 'coverage/',
			reporters: [
				{ type: 'text-summary', subdir: '.', file: 'text-summary.txt' },
				{type: 'html', dir : 'coverage/',}
			],
			includeAllSources: true
		},
        logLevel: config.LOG_INFO, //config.LOG_INFO, config.LOG_DEBUG
        autoWatch: true,
        singleRun: false,
        colors: true,
        port: 9876,
        basePath: '',
		
		webpack:webpackConfig,
		files: [ { pattern: 'webpack.karma.context.js', watched: false } ],
        preprocessors: { 'webpack.karma.context.js': ['webpack', 'sourcemap', 'coverage'] },
		
        //files: [
		//	'./node_modules/angular-mocks/angular-mocks.js',
		//	'./app/**/*.js',
		//	'./app/**/*.html'
		//],
        //preprocessors: { 
		//	'./app/**/*.html': ['ng-html2js'],
		//	'./app/**/!(*.mock|*.spec|*.test).js': ['coverage', 'webpack', 'sourcemap']
		//},
		//ngHtml2JsPreprocessor: {
		//	// strip this from the file path
		//	stripPrefix: 'app/',
		//	// create a single module that contains templates from all the files
		//	moduleName: 'templates'
		//},
        exclude: [],
		webpackServer: {
			noInfo: true,
		},
		concurrency: Infinity,
		plugins:[
        require('karma-webpack'),
        'karma-chrome-launcher',
		'karma-jasmine',
		'karma-coverage',
		'karma-spec-reporter',
		'karma-sourcemap-loader'
		]
    });
};